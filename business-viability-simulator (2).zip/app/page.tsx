import { BusinessSimulator } from "@/components/business-simulator"

export default function Page() {
  return <BusinessSimulator />
}
